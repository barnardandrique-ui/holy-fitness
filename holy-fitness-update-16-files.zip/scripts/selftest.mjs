// scripts/selftest.mjs — quick safety net. Run with:  node scripts/selftest.mjs
// Checks the plan generator and its health screening without needing any services.
import fs from 'node:fs';
import vm from 'node:vm';
import { generatePlan } from '../lib/planner/engine.js';
import { POOLS } from '../lib/planner/library.js';
import { TEMPLATES } from '../lib/planner/exercises.js';
import { FOODS, FOOD_BY_ID } from '../lib/planner/foods.js';
import { suggestSwaps, applySwap, undoMeal, swapEverywhere } from '../lib/planner/swaps.js';
import * as PUSH from '../lib/push.js';
import * as ADM from '../lib/admin.js';
import * as SHOP from '../lib/planner/shopping.js';
import { JOINT_UNFRIENDLY } from '../lib/planner/safety.js';

let bad = 0;
const check = (name, ok) => { console.log(ok ? 'OK  ' : 'FAIL', name); if (!ok) bad++; };
const base = { gender: 'male', age: 28, height: 180, weight: 82, bf: 15, freq: '4', exp: 'intermediate', goal: 'muscle gain', diet: 'standard', allerg: 'none' };
const ex = p => p.days.flatMap(d => d.training.exercises);

const plain = generatePlan(base, { seed: 7 });
check('normal plan: 7 days, sensible calories, no NaN', plain.days.length === 7 && plain.overview.dailyCalories > 1500 && !/NaN|undefined|Infinity/.test(JSON.stringify(plain)));
check('same seed gives the same plan', JSON.stringify(generatePlan(base, { seed: 7 })) === JSON.stringify(generatePlan(base, { seed: 7 })));

for (const k of ['heart', 'chestPain', 'dizzy', 'diabetesMeds', 'kidney', 'pregnant', 'eatingDisorder']) {
  const r = generatePlan({ ...base, health: { [k]: true } }, { seed: 7 });
  check(`"${k}" blocks the plan and returns no plan data`, r.blocked === true && !r.days && !r.overview);
}
check('eating-disorder message points to South African support', /sadag\.org/.test(generatePlan({ ...base, health: { eatingDisorder: true } }, { seed: 7 }).message));
check('eating-disorder message has no numbers', !/\d/.test(generatePlan({ ...base, health: { eatingDisorder: true } }, { seed: 7 }).message.replace('allianceforeatingdisorders.com', '')));

const joints = generatePlan({ ...base, goal: 'athletic performance', health: { joints: true } }, { seed: 7 });
check('joint problems: no jumping / high-impact exercises', ex(joints).every(e => !JOINT_UNFRIENDLY.has(e.name)));
const bp = generatePlan({ ...base, health: { bloodPressure: true } }, { seed: 7 });
check('high blood pressure: gentle sets and a caution note', ex(bp).every(e => +e.sets <= 3) && bp.notes.some(n => n.level === 'caution'));
const cut = generatePlan({ ...base, goal: 'fat loss', bf: 30, health: { pcos: true }, gender: 'female' }, { seed: 7 });
check('PCOS: calorie deficit capped at 15%', cut.meta.targetKcal / cut.meta.maintenance >= 0.85);


// ── Daily targets, celebration and history (js/progress.js) ──
const pctx = {}; pctx.globalThis = pctx; vm.createContext(pctx);
vm.runInContext(fs.readFileSync(new URL('../js/progress.js', import.meta.url), 'utf8'), pctx);
const PR = pctx.HFProgress;
const day = plain.days[0];
const fullLog = () => ({ workout: { saved: true, checks: day.training.exercises.map(() => true) }, meals: { saved: true, checks: day.nutrition.meals.map(() => true), custom: [] }, sleep: { saved: true, hours: String(day.sleep.targetHours) } });
check('celebration: a fully logged day counts as perfect', PR.evaluateDay(day, fullLog()).perfect === true);
const skipMeal = fullLog(); skipMeal.meals.checks[0] = false;
check('celebration: skipping a planned meal is not perfect', PR.evaluateDay(day, skipMeal).perfect === false);
const pizza = fullLog(); pizza.meals.custom = [{ name: 'Extra', calories: 5000 }];
check('celebration: huge extra calories are not perfect (no party for overeating)', PR.evaluateDay(day, pizza).perfect === false);
const shortSleep = fullLog(); shortSleep.sleep.hours = String(day.sleep.targetHours - 2);
check('celebration: well under the sleep target is not perfect', PR.evaluateDay(day, shortSleep).perfect === false);
const E = (date, perfect) => ({ id: date, planId: 'p', dayIndex: 0, date, hits: perfect ? 3 : 1, perfect: perfect ? 1 : 0, w: [0, 0, 1], m: [0, 0, 0, 0, 0], s: [null, 8, 0, ''] });
check('history: three perfect days in a row make a streak of three', PR.streaks([E('2026-10-15', 1), E('2026-10-16', 1), E('2026-10-17', 1)], '2026-10-17').current === 3);
check('history: a missed day breaks the streak', PR.streaks([E('2026-10-14', 1), E('2026-10-16', 1)], '2026-10-16').current === 1);


// ── Add App to Home Screen (js/install.js + the files a browser needs to treat the site as an app) ──
const ictx = {}; ictx.globalThis = ictx; vm.createContext(ictx);
vm.runInContext(fs.readFileSync(new URL('../js/install.js', import.meta.url), 'utf8'), ictx);
const IN = ictx.HFInstall;
const iphone = IN.detectPlatform('Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1', '', 5, false);
const droid = IN.detectPlatform('Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', '', 5, false);
check('install: iPhone gets the Share / Add to Home Screen guide', IN.installMode(iphone, false) === 'ios');
check('install: Android Chrome with a browser prompt uses the one-tap install', IN.installMode(droid, true) === 'native');
const samsung = IN.detectPlatform('Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/24.0 Chrome/117.0.0.0 Mobile Safari/537.36', '', 5, false);
check('install: Samsung Internet is guided to Chrome (its own install package trips Play Protect)', IN.installMode(samsung, true) === 'samsung');
check('install: nothing is offered once the app is already installed', IN.installMode({ ...droid, standalone: true }, true) === 'none');
const man = JSON.parse(fs.readFileSync(new URL('../site.webmanifest', import.meta.url), 'utf8'));
check('install: manifest has 192 + 512 icons and a maskable icon', ['192x192', '512x512'].every(sz => man.icons.some(i => i.sizes === sz)) && man.icons.some(i => i.purpose === 'maskable') && man.display === 'standalone');
check('install: every manifest icon file exists', man.icons.every(i => fs.existsSync(new URL('..' + i.src, import.meta.url))));
check('install: service worker and offline page exist', fs.existsSync(new URL('../sw.js', import.meta.url)) && fs.existsSync(new URL('../offline.html', import.meta.url)));
const swText = fs.readFileSync(new URL('../sw.js', import.meta.url), 'utf8');
check('install: the service worker never caches scripts, styles or the API', !/\/api/.test(swText) && !/app\.js|\.css/.test(swText));


// ── Exercise library + Training Center (data/exercises.json, exercises/<id>/0.webp, js/training.js) ──
const entries = Object.values(POOLS).flat();
check('library: every pool entry has an id, a name and a level', entries.every(e => e.id && e.name && [1, 2, 3].includes(e.lvl)));
check('library: no exercise is repeated inside a pool', Object.values(POOLS).every(arr => new Set(arr.map(e => e.id)).size === arr.length));
const slotRoles = {}; Object.values(TEMPLATES).forEach(t => t.slots.forEach(sl => (slotRoles[sl.pool] = slotRoles[sl.pool] || new Set()).add(sl.role)));
check('library: no exercise is unreachable (accessory-only exercises live only in pools that have accessory slots)', Object.entries(POOLS).every(([p, arr]) => !arr.some(e => e.noMain) || [...(slotRoles[p] || [])].some(r => !['main', 'secondary'].includes(r))));
check('library: jumps, throws and swings are never marked safe for gentle plans', POOLS.power.every(e => !e.li));
const risky = /\b(jump|jumps|hop|hops|bound|swing|swings|slam|throw|plyo|dip|dips|pull.?ups?|pullups|chins?|chin.?ups?|hanging|roller|walking|step.?ups?|bulgarian|decline|behind)\b|leg raise|front barbell|good morning/i;
check('library: no high-impact or joint-stressing exercise is marked safe for gentle plans', entries.every(e => !(e.li && risky.test(e.name))));
check('library: every training exercise in a plan carries a library id', plain.days.every(d => !d.training || (d.training.exercises || []).every(x => x.libId || /Intervals|Walk|Carry|Treadmill|Ski/.test(x.name))));
const dataUrl = new URL('../data/exercises.json', import.meta.url);
check('training media: data/exercises.json is present (upload and unzip the media bundle first)', fs.existsSync(dataUrl));
if (fs.existsSync(dataUrl)) {
  const lib = JSON.parse(fs.readFileSync(dataUrl, 'utf8')); const byId = Object.fromEntries(lib.map(e => [e.id, e]));
  check('training media: the library has hundreds of exercises', lib.length > 800);
  check('library: every planner exercise exists in the data with its exact name', entries.every(e => byId[e.id] && byId[e.id].name === e.name));
  check('training media: every planner exercise has both photos on disk', entries.every(e => fs.existsSync(new URL('../exercises/' + e.id + '/0.webp', import.meta.url)) && fs.existsSync(new URL('../exercises/' + e.id + '/1.webp', import.meta.url))));
  const tctx = {}; tctx.globalThis = tctx; vm.createContext(tctx);
  vm.runInContext(fs.readFileSync(new URL('../js/training.js', import.meta.url), 'utf8'), tctx);
  const found = tctx.HFTraining.filterExercises(tctx.HFTraining.prepare(lib), { q: 'squat' }).slice(0, 6).map(e => e.name);
  check('training center: searching "squat" puts everyday beginner squats first', found.length === 6 && found.every(n => /squat/i.test(n)) && !found.includes('Squat Jerk'));
  check('training center: "abs" finds abdominal exercises', tctx.HFTraining.filterExercises(tctx.HFTraining.prepare(lib), { q: 'abs' }).length > 50);
}
const vj = JSON.parse(fs.readFileSync(new URL('../vercel.json', import.meta.url), 'utf8'));
check('hosting: exercise photos are cached by browsers (vercel.json)', JSON.stringify(vj).includes('/exercises/') && JSON.stringify(vj).includes('max-age'));


// ── Food swaps ("can't eat it", "too expensive", "hard to find") ──
check('swaps: every food has a job, a cost tier and an availability tier', FOODS.every(f => ['protein', 'carb', 'fat', 'veg'].includes(f.role) && [1, 2, 3].includes(f.cost) && [1, 2, 3].includes(f.avail)));
const allMeals = plain.days.flatMap(d => d.nutrition.meals);
check('swaps: every meal keeps its ingredients and they match the meal text', allMeals.every(m => Array.isArray(m.items) && m.items.length && m.items.map(i => i[2]).join(', ') === m.foods && m.type));
const sMeal = plain.days[0].nutrition.meals.find(m => m.type === 'main');
const sIdx = sMeal.items.findIndex(i => FOOD_BY_ID[i[0]].role === 'protein');
const sProf = { diet: 'standard', allerg: 'none', avoid: [] };
const sugg = suggestSwaps(sMeal, sIdx, { profile: sProf, reason: 'any' });
check('swaps: a protein can be swapped, and the best alternative keeps the meal on target', sugg.ok && sugg.candidates.length > 0 && sugg.candidates[0].onTarget);
const sApplied = applySwap(sMeal, sIdx, sugg.candidates[0].id, { profile: sProf });
check('swaps: applying a swap stays close to the meal calories and protein', Math.abs(sApplied.calories - sMeal.calories) <= Math.max(0.07 * sMeal.calories, 16) && Math.abs(sApplied.protein - sMeal.protein) <= Math.max(4, 0.13 * sMeal.protein));
check('swaps: undo restores the original meal exactly', JSON.stringify(undoMeal(sApplied)) === JSON.stringify(sMeal));
// Accuracy across many meals and plans (a single lucky meal must not be able to hide a broken solver)
let swN = 0, swOn = 0, swDrift = 0, swItems = 0;
for (const seed of [4, 9, 21, 33, 57, 71]) {
  const pl = generatePlan({ gender: seed % 2 ? 'male' : 'female', age: 30, height: 172, weight: 74, bf: 20, freq: '4', exp: 'intermediate', goal: 'muscle gain', diet: 'standard' }, { seed });
  for (const m of pl.days.flatMap(d => d.nutrition.meals)) m.items.forEach((it, i) => {
    if (!['protein', 'carb'].includes(FOOD_BY_ID[it[0]].role)) return;
    const top = suggestSwaps(m, i, { profile: sProf, reason: 'any' }).candidates[0];
    swItems++;
    if (top) { swN++; if (top.onTarget) swOn++; swDrift += Math.abs(top.meal.calories - m.calories) / Math.max(m.calories, 1); }
  });
}
check('swaps: across many meals the best alternative keeps the meal on target at least 90% of the time', swN > 100 && swOn / swN >= 0.9);
check('swaps: nearly every protein and carb food has at least one alternative (95%+)', swItems > 100 && swN / swItems >= 0.95);
check('swaps: the average calorie change after a swap is under 3%', swN > 100 && swDrift / swN < 0.03);
const exp = suggestSwaps(sMeal, sIdx, { profile: sProf, reason: 'expensive' });
check('swaps: "too expensive" only offers cheaper foods (or says why not)', exp.candidates.every(c => c.cost < FOOD_BY_ID[sMeal.items[sIdx][0]].cost) || !!exp.note);
const veganMeal = { type: 'main', name: 'Lunch · Tofu with White Rice', items: [['tofu', 200, 't'], ['white_rice', 220, 'r']] };
check('swaps: a vegan is never offered meat, eggs or dairy', suggestSwaps(veganMeal, 0, { profile: { diet: 'vegan', allerg: 'none' } }).candidates.every(c => !FOOD_BY_ID[c.id].tags.some(t => ['flesh', 'egg', 'dairy'].includes(t))));
check('swaps: foods a client avoids are never offered', !suggestSwaps(sMeal, sIdx, { profile: { ...sProf, avoid: ['turkey', 'chicken_thigh', 'hake', 'lean_beef'] } }).candidates.some(c => ['turkey', 'chicken_thigh', 'hake', 'lean_beef'].includes(c.id)));
const avoidPlan = generatePlan({ gender: 'male', age: 30, height: 180, weight: 82, bf: 16, freq: '4', exp: 'intermediate', goal: 'muscle gain', diet: 'standard', avoid: ['chicken', 'white_rice', 'broccoli'] }, { seed: 11 });
check('swaps: a food on the avoid list never appears in a new plan', !avoidPlan.days.flatMap(d => d.nutrition.meals.flatMap(m => m.items.map(i => i[0]))).some(id => ['chicken', 'white_rice', 'broccoli'].includes(id)));
const swapPlan = JSON.parse(JSON.stringify(plain)); const sw1 = swapEverywhere(swapPlan, sMeal.items[sIdx][0], sugg.candidates[0].id, { profile: sProf });
check('swaps: swapping everywhere keeps every day total equal to its meals', sw1.changed >= 1 && swapPlan.days.every(d => d.nutrition.totalCalories === d.nutrition.meals.reduce((a, m) => a + m.calories, 0)));
const appHtml = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8'), appJs = fs.readFileSync(new URL('../js/app.js', import.meta.url), 'utf8'), stateJs = fs.readFileSync(new URL('../api/state.js', import.meta.url), 'utf8');
check('swaps: the swap dialog and Swap buttons are wired into the app', /id="swap-modal"/.test(appHtml) && /openSwap\(/.test(appJs) && /import\('\/lib\/planner\/swaps\.js'\)/.test(appJs));
check('swaps: the server keeps deep meal data and the avoid list when saving', /depth > 12/.test(stateJs) && /avoidFoods/.test(stateJs));


// ── Body measurements, goals and plan updates (js/body.js) ──
const bctx = {}; bctx.globalThis = bctx; vm.createContext(bctx);
vm.runInContext(fs.readFileSync(new URL('../js/body.js', import.meta.url), 'utf8'), bctx);
const BD = bctx.HFBody; const bToday = '2026-10-26';
const okEntry = w => BD.validateEntry({ date: bToday, weight: w }, { today: bToday, entries: [] }).ok;
check('body: a normal weight is accepted; impossible weights, junk and a future date are refused', okEntry('82.5') && !okEntry('12') && !okEntry('900') && !okEntry('abc') && !BD.validateEntry({ date: '2026-10-27', weight: '80' }, { today: bToday }).ok);
check('body: goals below BMI 18.5 are refused (we never help someone aim that low)', !BD.checkTargets({ weight: '55' }, { gender: 'male', heightCm: 180 }).ok && BD.checkTargets({ weight: '75' }, { gender: 'male', heightCm: 180 }).ok);
check('body: body-fat goals below the safe floors (men 6%, women 14%) are refused', !BD.checkTargets({ bf: '5' }, { gender: 'male' }).ok && !BD.checkTargets({ bf: '13' }, { gender: 'female' }).ok && BD.checkTargets({ bf: '14' }, { gender: 'female' }).ok);
const gT = { weight: 80, bf: null, startWeight: 90, startBf: null };
check('body: one lucky low weigh-in does NOT reach a goal (the 7-day trend decides)', BD.goalProgress(gT, [{ d: '2026-10-21', w: 82 }, { d: '2026-10-23', w: 82.4 }, { d: '2026-10-26', w: 79.5 }]).reached === false);
check('body: a sustained trend at the target does reach it (losing and gaining)', BD.goalProgress(gT, [{ d: '2026-10-23', w: 79.9 }, { d: '2026-10-26', w: 79.8 }]).reached === true && BD.goalProgress({ weight: 85, bf: null, startWeight: 78, startBf: null }, [{ d: '2026-10-24', w: 85.1 }, { d: '2026-10-26', w: 85.3 }]).reached === true);
const bMeta = { weightKg: 84, profile: { weight: 84, bf: 16 } };
check('body: the plan is flagged for an update after about 3% weight or 2 points of body fat, not before', BD.planChangeAdvice(bMeta, [{ d: bToday, w: 82.8, bf: 15.2 }]) === null && BD.planChangeAdvice(bMeta, [{ d: bToday, w: 81.4 }]) !== null && BD.planChangeAdvice(bMeta, [{ d: bToday, w: 84, bf: 13.9 }]) !== null);
const profileKeys = ['age', 'allerg', 'bf', 'cycle', 'diet', 'exp', 'freq', 'gender', 'goal', 'height', 'sleep', 'stress', 'weight'];
check('body: a plan keeps a snapshot of exactly the approved non-health numbers, and nothing else', plain.meta.profile && Object.keys(plain.meta.profile).sort().join() === profileKeys.join());
check('body: plan metadata holds only approved fields (a new field must be added here on purpose, so nothing sensitive slips in)', Object.keys(plain.meta).sort().join() === 'allerg,avoid,bmr,diet,engine,ffmi,freq,goal,leanMassKg,maintenance,mode,profile,seed,targetKcal,weightKg');
const healthPlan = generatePlan({ gender: 'male', age: 40, height: 180, weight: 90, bf: 22, freq: '3', exp: 'beginner', goal: 'fat loss', diet: 'standard', health: { joints: true, bloodPressure: true, otherCondition: true } }, { seed: 5 });
check('body: even when health boxes are ticked, no health answers are kept in the plan metadata', !healthPlan.blocked && !/joints|bloodPressure|otherCondition|health/i.test(JSON.stringify(healthPlan.meta)));
check('body: the server validates measurements and goals', /cleanMeasurements/.test(stateJs) && /w < 30 \|\| w > 300/.test(stateJs) && /cleanTargets/.test(stateJs) && /out\.measurements/.test(stateJs));
check('body: updating a plan always asks the health check again, and the Body tab and dialogs are wired in', /function openPlanUpdate/.test(appJs) && /input\[type=checkbox\]'\)\.forEach\(c => \{ c\.checked = false; \}\)/.test(appJs) && /id="body-modal"/.test(appHtml) && /id="goal-modal"/.test(appHtml) && /id="htab-body"/.test(appHtml));


// ── Reminders (web push): lib/push.js, api/push.js, api/cron/remind.js, sw.js, js/push.js ──
const swSrc = fs.readFileSync(new URL('../sw.js', import.meta.url), 'utf8'), pushLib = fs.readFileSync(new URL('../lib/push.js', import.meta.url), 'utf8');
const cronSrc = fs.readFileSync(new URL('../api/cron/remind.js', import.meta.url), 'utf8'), dbSrc = fs.readFileSync(new URL('../lib/db.js', import.meta.url), 'utf8');
const privacyHtml = fs.readFileSync(new URL('../privacy.html', import.meta.url), 'utf8');
const vercelCfg = JSON.parse(fs.readFileSync(new URL('../vercel.json', import.meta.url), 'utf8')), pkgJson = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const countApi = dir => fs.readdirSync(dir, { withFileTypes: true }).reduce((n, e) => n + (e.isDirectory() ? countApi(new URL(e.name + '/', dir)) : /\.js$/.test(e.name) ? 1 : 0), 0);
check('reminders: only the browser makers\' push services are accepted (the server can never be pointed at another address)', ['https://fcm.googleapis.com/fcm/send/a', 'https://updates.push.services.mozilla.com/wpush/v2/a', 'https://web.push.apple.com/a'].every(PUSH.isAllowedEndpoint) && ['http://fcm.googleapis.com/a', 'https://localhost/a', 'https://169.254.169.254/a', 'https://evil.com/a', 'https://fcm.googleapis.com.evil.com/a', 'https://fcm.googleapis.com@evil.com/a'].every(u => !PUSH.isAllowedEndpoint(u)));
check('reminders: times can only be set between 06:00 and 21:30 (nobody is pinged at night)', PUSH.parseTime('06:00') === 360 && PUSH.parseTime('21:30') === 1290 && ['00:00', '02:00', '05:45', '21:45', '23:30'].every(x => PUSH.parseTime(x) === null));
const msgKinds = ['daily', 'weekly', 'test', 'goal_reached', 'perfect_week', 'streak_7'];
check('reminders: LOCK-SCREEN PRIVACY: messages never contain weight, calories, body fat, health words or numbers', msgKinds.every(k => !/kg|kcal|calor|weigh|fat|bmi|health|medic|diabet|pregnan|\d|%/i.test(PUSH.buildMessage(k).body)));
check('reminders: made-up milestone kinds are refused', ['streak_5', 'streak_1000', '<script>', 'daily', ''].every(k => PUSH.buildMessage(k) === null || k === 'daily') && !PUSH.isMilestoneKind('daily') && !PUSH.isMilestoneKind('streak_5') && PUSH.isMilestoneKind('goal_reached'));
const rDoc = { prefs: { ...PUSH.DEFAULT_PREFS(), weekly: { on: true, day: 1, time: '07:30' } }, subs: [{ id: 'a' }], lastSent: {} }, rPlan = { plan: { days: [] }, history: [], measurements: [] };
const rAt = (d, hm) => Date.parse(`${d}T${hm}:00+02:00`);
check('reminders: the daily nudge is skipped if the person already logged today, and sent otherwise', PUSH.dueReminder(rDoc, rPlan, rAt('2026-10-27', '18:30'))?.kind === 'daily' && PUSH.dueReminder(rDoc, { ...rPlan, history: [{ date: '2026-10-27' }] }, rAt('2026-10-27', '18:30')) === null);
check('reminders: at most one a day, never twice, and not before the chosen time', PUSH.dueReminder({ ...rDoc, lastSent: { any: '2026-10-27' } }, rPlan, rAt('2026-10-27', '18:45')) === null && PUSH.dueReminder(rDoc, rPlan, rAt('2026-10-27', '18:00')) === null);
check('reminders: the weekly check-in is skipped if they weighed in recently', PUSH.dueReminder(rDoc, { ...rPlan, measurements: [{ d: '2026-10-24' }] }, rAt('2026-10-26', '07:30')) === null && PUSH.dueReminder(rDoc, rPlan, rAt('2026-10-26', '07:30'))?.kind === 'weekly');
check('reminders: the scheduled job needs the secret (compared safely) and the keys', /CRON_SECRET/.test(cronSrc) && /timingSafeEqual/.test(cronSrc) && /401/.test(cronSrc) && /vapidConfig\(\)/.test(cronSrc));
check('reminders: the server stays within the free plan limit of 12 functions', countApi(new URL('../api/', import.meta.url)) <= 12);
check('reminders: no scheduled job in vercel.json runs more often than daily (the free plan would refuse to deploy)', !vercelCfg.crons || vercelCfg.crons.every(c => /^\d+ \d+ \* \* \*$/.test(c.schedule)));
check('reminders: the service worker shows notifications and opens the right screen, and still never caches private data', /addEventListener\('push'/.test(swSrc) && /notificationclick/.test(swSrc) && /showNotification/.test(swSrc) && !/\/api/.test(swSrc) && !/app\.js|\.css/.test(swSrc));
check('reminders: web-push is a dependency and is loaded only when something is sent', !!pkgJson.dependencies['web-push'] && !/^import .*['"]web-push['"]/m.test(pushLib) && /import\('web-push'\)/.test(pushLib));
check('reminders: deleting an account deletes its reminder devices and schedule entry', /push:\$\{user\.id\}/.test(dbSrc) && /srem\('push:users'/.test(dbSrc));
check('reminders: the privacy policy explains reminders, and reminders are opt-in from the Account dialog', /Reminders \(only if you switch them on\)/.test(privacyHtml) && /HFPush\.open\(\)/.test(appHtml) && /id="remind-modal"/.test(appHtml));


// ── Reminder server settings: the mistakes people make when pasting into Vercel must be cleaned or explained, never a vague failure ──
const vp = (await import('node:crypto')).generateKeyPairSync('ec', { namedCurve: 'prime256v1' }), vpj = vp.publicKey.export({ format: 'jwk' });
const vPub = Buffer.concat([Buffer.from([4]), Buffer.from(vpj.x, 'base64url'), Buffer.from(vpj.y, 'base64url')]).toString('base64url'), vPriv = vp.privateKey.export({ format: 'jwk' }).d;
const vEnv = o => ({ VAPID_PUBLIC_KEY: vPub, VAPID_PRIVATE_KEY: vPriv, VAPID_SUBJECT: 'mailto:owner@example.com', ...o });
check('reminders: settings pasted with quote marks, a NAME= prefix or stray spaces are cleaned up and then valid', ['"' + vPriv + '"', 'VAPID_PRIVATE_KEY=' + vPriv, ' ' + vPriv + '\n'].every(k => PUSH.vapidProblems(PUSH.vapidConfig(vEnv({ VAPID_PRIVATE_KEY: k }))).length === 0));
check('reminders: an email entered without "mailto:", or with a note after it, is fixed (the real library would reject it)', PUSH.normalizeVapid(vEnv({ VAPID_SUBJECT: 'owner@gmail.com' })).subject === 'mailto:owner@gmail.com' && PUSH.normalizeVapid(vEnv({ VAPID_SUBJECT: 'mailto:owner@gmail.com   <- put your own email here' })).subject === 'mailto:owner@gmail.com');
check('reminders: a space after "mailto:" is fixed, and "mailto:" with no address is reported (never sent as a contact)', PUSH.normalizeVapid(vEnv({ VAPID_SUBJECT: 'mailto: owner@gmail.com' })).subject === 'mailto:owner@gmail.com' && PUSH.vapidProblems(PUSH.vapidConfig(vEnv({ VAPID_SUBJECT: 'mailto:' }))).some(p => /VAPID_SUBJECT/.test(p)));
check('reminders: wrong-length keys and public/private keys that do not belong together are reported in plain words, without showing the keys', PUSH.vapidProblems(PUSH.vapidConfig(vEnv({ VAPID_PRIVATE_KEY: 'short' }))).length === 1 && /do not belong together/.test(PUSH.vapidProblems(PUSH.vapidConfig(vEnv({ VAPID_PUBLIC_KEY: Buffer.concat([Buffer.from([4]), Buffer.alloc(64, 7)]).toString('base64url') }))).join(' ')) && !PUSH.vapidProblems(PUSH.vapidConfig(vEnv({ VAPID_PRIVATE_KEY: 'short' }))).join('').includes(vPriv));
check('reminders: error text for the owner never contains a secret', PUSH.redact('x ' + vPriv, { VAPID_PRIVATE_KEY: vPriv }) === 'x ***');
check('reminders: the job has a ?check=1 mode (needs the password) and sending says exactly which setting is wrong', /check/.test(cronSrc) && /vapidProblems/.test(cronSrc) && /problems/.test(cronSrc) && /vapidProblems/.test(fs.readFileSync(new URL('../api/push.js', import.meta.url), 'utf8')));


// ── Admin panel (lib/admin.js, api/admin.js, admin.html): SEPARATION and PRIVACY rules ──
const admApi = fs.readFileSync(new URL('../api/admin.js', import.meta.url), 'utf8'), admLib = fs.readFileSync(new URL('../lib/admin.js', import.meta.url), 'utf8'), meApi = fs.readFileSync(new URL('../api/auth/me.js', import.meta.url), 'utf8'), admPage = fs.readFileSync(new URL('../admin.html', import.meta.url), 'utf8');
const bcrypt60 = '$2a$10$' + 'a'.repeat(53);
const admEnv = { ADMIN_1_EMAIL: 'one@example.com', ADMIN_1_HASH: bcrypt60, ADMIN_2_EMAIL: 'two@example.com', ADMIN_2_HASH: bcrypt60, ADMIN_3_EMAIL: 'three@example.com', ADMIN_3_HASH: bcrypt60, ADMIN_SESSION_SECRET: 'a'.repeat(40), SESSION_SECRET: 'b'.repeat(40) };
check('admin: there are exactly TWO admin slots, a third in the settings is ignored, and nothing in the code can create an admin', ADM.MAX_ADMINS === 2 && ADM.adminSlots(admEnv).length === 2 && !ADM.adminSlots(admEnv).some(x => x.email === 'three@example.com') && /for \(const n of \[1, 2\]\)/.test(admLib) && !/ADMIN_3|createAdmin|addAdmin|promote/i.test(admApi + admLib));
check('admin: the admin session secret must be long and DIFFERENT from the client one (client and admin sessions can never be confused)', ADM.adminEnabled(admEnv) && !ADM.adminEnabled({ ...admEnv, ADMIN_SESSION_SECRET: admEnv.SESSION_SECRET }) && !ADM.adminEnabled({ ...admEnv, ADMIN_SESSION_SECRET: 'short' }));
check('admin: authenticator codes match the official RFC 6238 test vectors and a code works only once', ADM.totpAt('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', 1) === '287082' && ADM.verifyTotp('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', '287082', 59000).ok && !ADM.verifyTotp('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', '287082', 59000, 1).ok);
check('admin: the admin cookie is a different cookie, limited to /api/admin, SameSite=Strict, and the admin API never touches the client session', /COOKIE_PATH = '\/api\/admin'/.test(admLib) && /SameSite=Strict/.test(admApi) && !/lib\/session\.js|hf_session|(?<!ADMIN_)SESSION_SECRET/.test(admApi) && /ADMIN_SESSION_SECRET/.test(admApi));
check('admin: everyone who is not a signed-in admin gets a plain 404, and sessions end after 30 idle minutes or 8 hours', /const notFound/.test(admApi) && /notFound\(res\); return null/.test(admApi) && ADM.SESSION_IDLE_MS === 30 * 60000 && ADM.SESSION_MAX_MS === 8 * 3600000);
check('admin: full client details need the client\'s consent (checked on every request, so revoking works at once) and every view is logged', /user\.coach && user\.coach\.share/.test(admApi) && /audit\(req, admin, 'view_account'/.test(admApi) && /audit\(req, admin, 'view_basic'/.test(admApi) && /audit\(req, admin, 'export_/.test(admApi));
check('admin: the panel is read-only for client data (the only POSTs are login and logout)', !/setState|deleteUser/.test(admApi) && (admApi.match(/req\.method === 'POST'/g) || []).length === 2);
const admUser = { id: 'u1', name: 'Zed', email: 'z@x.co', passwordHash: 'SECRETHASH', sv: 3, consentAt: 1, createdAt: '2026-10-01T00:00:00Z', plansGenerated: 2, coach: { share: true }, resetToken: 'tok' };
check('admin: a list row holds ONLY approved fields; never a password hash, session data or tokens', Object.keys(ADM.accountRow(admUser, plain && { plan: plain, updatedAt: 1 })).sort().join() === 'coachShare,createdAt,daysPerWeek,email,hasPlan,id,interest,lastActiveAt,lastLoginAt,name,plansGenerated,program' && !/SECRETHASH|resetToken|"sv"|consentAt/.test(JSON.stringify(ADM.accountRow(admUser, null)) + JSON.stringify(ADM.clientDetail(admUser, { plan: plain, history: [], measurements: [] }))));
const admItem = i => ({ user: { id: 'i' + i, name: 'N' + i, email: i + '@x.co', createdAt: '2026-10-20T00:00:00Z', coach: { share: false } }, state: { plan: { meta: { goal: i < 6 ? 'fat loss' : 'muscle gain', freq: 4, profile: { exp: 'beginner' } }, days: [] }, history: [], updatedAt: Date.now() } });
const admIns = ADM.insights(Array.from({ length: 8 }, (_, i) => admItem(i)));
check('admin: statistics are anonymous: groups under 5 are hidden, and nothing is shown at all for fewer than 5 accounts', admIns.goals['fat loss'] === 6 && admIns.goals['muscle gain'] === '<5' && Object.keys(ADM.insights([0, 1, 2].map(admItem)).goals).length === 0 && ADM.K_MIN === 5);
check('admin: exports cannot run formulas in a spreadsheet', ADM.csvCell('=1+1') === "'=1+1" && ADM.csvCell('@SUM(A1)').startsWith("'") && ADM.csvCell('+1').startsWith("'") && ADM.csvCell('-2').startsWith("'"));
const mkAdmin = fs.readFileSync(new URL('./make-admin.mjs', import.meta.url), 'utf8'), gitIgn = fs.readFileSync(new URL('../.gitignore', import.meta.url), 'utf8');
check('admin setup: the login settings are saved to a private file that git ignores, and nothing private is ever printed on screen', /admin-settings/.test(gitIgn) && /FILE = 'admin-settings\.txt'/.test(mkAdmin) && /mode: 0o600/.test(mkAdmin) && !/console\.log\([^\n]*(hash|secret|totp|items|text)/i.test(mkAdmin));
// ── Weekly shopping list (lib/planner/shopping.js): cooked amounts must be turned back into what you actually buy ──
const shopStateSrc = fs.readFileSync(new URL('../api/state.js', import.meta.url), 'utf8');
const shopVegan = generatePlan({ ...base, diet: 'vegan' }, { seed: 3 }), shopPlain = SHOP.buildShoppingList(plain), shopVeg = SHOP.buildShoppingList(shopVegan);
const shopEaten = {}; for (const d of plain.days) for (const m of d.nutrition.meals) for (const it of m.items) shopEaten[it[0]] = (shopEaten[it[0]] || 0) + it[1];
check('shopping: every food the planner can use has a shopping entry, and the cooked-to-raw conversions are sane (chicken bought raw is MORE than eaten, rice bought dry is LESS)', FOODS.every(f => SHOP.SHOP[f.id]) && Object.keys(SHOP.SHOP).every(id => FOOD_BY_ID[id]) && SHOP.SHOP.chicken[2] > 1 && SHOP.SHOP.white_rice[2] < 0.5 && Object.values(SHOP.SHOP).every(e => e[2] >= 0.3 && e[2] <= 1.7));
check('shopping: a plan builds a list with every food on it once, amounts rounded UP so nobody runs short, eggs in whole numbers', shopPlain.ok && shopPlain.count >= 10 && new Set(shopPlain.groups.flatMap(g => g.items.map(i => i.id))).size === shopPlain.count && shopPlain.groups.flatMap(g => g.items).every(i => !i.generic && (i.unit !== 'g' || i.amount >= shopEaten[i.id] * SHOP.SHOP[i.id][2])) && (shopPlain.groups.flatMap(g => g.items).find(i => i.id === 'egg') || { amount: 1 }).amount % 1 === 0);
check('shopping: a vegan plan never asks for meat, eggs or dairy', shopVeg.ok && shopVeg.groups.flatMap(g => g.items).every(i => !FOOD_BY_ID[i.id].tags.some(t => ['flesh', 'egg', 'dairy'].includes(t))));
check('shopping: swapping a food changes the list, and a plan from before ingredients were stored gets a clear message instead of a wrong list', (() => { const fixed = generatePlan({ gender: 'male', age: 30, height: 180, weight: 82, bf: 16, freq: '4', exp: 'intermediate', goal: 'muscle gain', diet: 'standard' }, { seed: 4 }); const had = SHOP.buildShoppingList(fixed).groups.flatMap(g => g.items).map(i => i.id); swapEverywhere(fixed, 'chicken', 'tofu', { profile: { diet: 'standard', allerg: 'none', avoid: [] } }); const l = SHOP.buildShoppingList(fixed).groups.flatMap(g => g.items).map(i => i.id); return had.includes('chicken') && !l.includes('chicken') && l.includes('tofu') && SHOP.buildShoppingList({ days: [{ nutrition: { meals: [{ foods: '100g chicken' }] } }] }).reason === 'old-plan'; })());
check('shopping: saved ticks are cleaned by the server (plain food ids and a date only, at most 80, weekly and monthly kept apart, the first version\'s format still read) and the Nutrition tab has the list screen', /function cleanTicks[\s\S]*?\\d\{4\}-\\d\{2\}-\\d\{2\}[\s\S]*?a-z0-9_\]\{1,40\}[\s\S]*?slice\(0, 80\)[\s\S]*?\n\}[\s\S]*?function cleanShopping[\s\S]*?Array\.isArray\(s\.done\)[\s\S]*?s\.month[\s\S]*?\n\}/.test(shopStateSrc) && /out\.shopping = cleanShopping/.test(shopStateSrc) && /id="shop-modal"/.test(appHtml) && /id="shop-p-month"/.test(appHtml) && /function openShopping/.test(appJs) && /function setShopPeriod/.test(appJs) && /shopCard/.test(appJs));
const shopFixed = generatePlan({ gender: 'male', age: 30, height: 180, weight: 82, bf: 16, freq: '4', exp: 'intermediate', goal: 'muscle gain', diet: 'standard' }, { seed: 4 });
const shopW = SHOP.buildShoppingList(shopFixed), shopM = SHOP.buildShoppingList(shopFixed, { period: 'month' }), wAll = shopW.groups.flatMap(g => g.items), mAll = shopM.groups.flatMap(g => g.items), wId = Object.fromEntries(wAll.map(i => [i.id, i]));
check('shopping: the MONTHLY list has the same foods as the weekly one, split into stock-up and a weekly-fresh section; fresh items keep their weekly amounts and stock-up items are about 4x', shopM.ok && shopM.days === 30 && JSON.stringify(mAll.map(i => i.id).sort()) === JSON.stringify(wAll.map(i => i.id).sort()) && shopM.groups.at(-1).id === 'fresh' && mAll.filter(i => i.weekly).every(i => i.display === wId[i.id].display && SHOP.FRESH.has(i.id) && i.bucket === 'week') && mAll.filter(i => !i.weekly).every(i => i.bucket === 'month' && !SHOP.FRESH.has(i.id) && i.amount >= wId[i.id].amount) && mAll.filter(i => !i.weekly && i.unit === 'g' && i.eaten > 400).every(i => i.amount >= wId[i.id].amount * 3));
check('shopping: monthly never runs short (30 days of stock-up, one week of fresh), and foods that go off are weekly while meat and bread are marked for the freezer', mAll.every(i => { const e = wId[i.id].eaten, f = SHOP.SHOP[i.id][2], o = SHOP.SHOP[i.id][3] || {}, need = e * (i.weekly ? 1 : 30 / 7) * f; return i.unit === 'g' ? i.amount >= need - 1e-6 : i.unit === 'count' ? i.amount * o.count >= need - 1e-6 : true; }) && ['spinach', 'greek_yogurt', 'banana', 'avocado'].every(id => SHOP.FRESH.has(id)) && !['white_rice', 'almonds', 'olive_oil', 'egg'].some(id => SHOP.FRESH.has(id)) && mAll.filter(i => i.shelf === 'freeze').every(i => /freeze/.test(i.hint)) && mAll.some(i => i.shelf === 'freeze') && mAll.filter(i => i.shelf !== 'freeze').every(i => !/freeze/.test(i.hint)));
check('admin: the CLIENT app contains no admin code (the admin page is never loaded, the admin API is never called)', !/admin\.js|admin\.css/.test(appHtml) && !/api\/admin/.test(appJs) && !/js\/admin/.test(fs.readFileSync(new URL('../sw.js', import.meta.url), 'utf8')));
check('admin: the admin page is not indexed by search engines and has its own app identity', /noindex/.test(admPage) && /admin\.webmanifest/.test(admPage) && JSON.stringify(vercelCfg).includes('"/admin"') && /noindex/.test(JSON.stringify(vercelCfg)));
check('admin: the client\'s coaching switches are OFF unless a real true is sent, and the privacy policy explains administrator access', /=== true/.test(meApi) && /Who can see your information/.test(privacyHtml) && /Anonymous statistics/.test(privacyHtml) && /Personal training \(only if you opt in\)/.test(privacyHtml) && /id="coach-share"/.test(appHtml) && /id="coach-interest"/.test(appHtml));

console.log(bad ? `\n${bad} check(s) FAILED` : '\nAll checks passed.');
process.exit(bad ? 1 : 0);
